import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:todo_application/model/todo.dart';
import 'package:todo_application/network_utils/todo_utils.dart';


class TodoScreen extends StatefulWidget {
  const TodoScreen({super.key});

  @override
  TodoScreenState createState() => TodoScreenState();
}

class TodoScreenState extends State<TodoScreen> {
  final TextEditingController _taskController = TextEditingController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: const Text("Todo Screen"),
      ),
      body: FutureBuilder(builder: (context, snapshot) {
        if (snapshot.data != null) {
          List<Todo>? todoList = snapshot.data;

          return ListView.builder(itemBuilder: (_, position) {
            return ListTile(
              title: Text(todoList![position].task),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  IconButton(icon: const Icon(Icons.edit), onPressed: () {
                    showUpdateDialog(todoList[position]);
                  }),
                  IconButton(icon: const Icon(Icons.check_circle, color: Colors.green,), onPressed: () {
                    deleteTodo(todoList[position].objectId);
                  })
                ],
              ),
            );
          },
            itemCount: todoList?.length,
          );

        } else {
          return const Center(
            child: CircularProgressIndicator(),
          );
        }
      },
        future: getTodoList(),
      ),
      floatingActionButton: FloatingActionButton(onPressed: () {
        showAddTodoDialog();
      },
        child: const Icon(Icons.add),
      ),
    );
  }



  void showUpdateDialog(Todo todo) {

    _taskController.text = todo.task;

    showDialog(context: context,
        builder: (_) => AlertDialog(
          content: SizedBox(
            width: double.maxFinite,
            child: TextField(
              controller: _taskController,
              decoration: const InputDecoration(
                labelText: "Enter updated task",
              ),
            ),
          ),
          actions: <Widget>[
            FloatingActionButton(onPressed: () {
              Navigator.pop(context);
              todo.task = _taskController.text;
              updateTodo(todo);
            }, child: const Text("Update")),
            FloatingActionButton(onPressed: () {
              Navigator.pop(context);
            }, child: const Text("Cancel")),
          ],
        )
    );


  }


  Future <List<Todo>> getTodoList() async{

    List<Todo> todoList = [];

    var response = await TodoUtils.getTodoList();

    if (response.statusCode == 200) {
      var body = json.decode(response.body);
      var results = body["results"];

      for (var todo in results) {
        todoList.add(Todo.fromJson(todo));
      }

    } else {
      //Handle error
    }

    return todoList;
  }




  void showAddTodoDialog() {

    showDialog(context: context,
        builder: (_) => AlertDialog(
          content: SizedBox(
            width: double.maxFinite,
            child: TextField(
              controller: _taskController,
              decoration: const InputDecoration(
                labelText: "Enter task",
              ),
            ),
          ),
          actions: <Widget>[
            FloatingActionButton(onPressed: () {

              Navigator.pop(context);
              addTodo();

            }, child: const Text("Add")),
            FloatingActionButton(onPressed: () {
              Navigator.pop(context);
            }, child: const Text("Cancel")),
          ],
        )
    );

  }

  void addTodo() {

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: const <Widget>[
        Text("Adding task"),
        CircularProgressIndicator(),
      ],
    ),
      duration: const Duration(minutes: 1),
    ));

    Todo todo = Todo(task: _taskController.text, objectId: '');

    TodoUtils.addTodo(todo)
        .then((res) {

      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      var response = res;
      if (response.statusCode == 201) {
        //Successful
        _taskController.text = "";

        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Todo added!"), duration: Duration(seconds: 1),));

        setState(() {

        });

      }

    });

  }


  void updateTodo(Todo todo) {

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: const <Widget>[
        Text("Updating todo"),
        CircularProgressIndicator(),
      ],
    ),
      duration: const Duration(minutes: 1),
    ),);


    TodoUtils.updateTodo(todo)
        .then((res) {

      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      var response = res;
      if (response.statusCode == 200) {
        //Successfully Deleted
        _taskController.text = "";
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: (Text("Updated!"))));
        setState(() {

        });
      } else {
        //Handle error
      }
    });


  }




  void deleteTodo(String objectId) {

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: const <Widget>[
        Text("Deleting todo"),
        CircularProgressIndicator(),
      ],
    ),
      duration: const Duration(minutes: 1),
    ),);


    TodoUtils.deleteTodo(objectId)
        .then((res) {

      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      var response = res;
      if (response.statusCode == 200) {
        //Successfully Deleted
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: (Text("Deleted!")),duration: Duration(seconds: 1),));
        setState(() {

        });
      } else {
        //Handle error
      }
    });

  }





}