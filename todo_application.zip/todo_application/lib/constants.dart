

//Todo : Paste the credentials from your project console in back4app.com
const kParseApplicationId = "YOUR_PARSE_APPLICATION_ID";
const kParseRestApiKey = "YOUR_PARSE_REST_API_KEY";