import 'dart:convert';
import 'package:todo_application/constants.dart';
import 'package:todo_application/model/todo.dart';

const String baseUrl = 'https://jsonplaceholder.typicode.com/todos';
class TodoUtils {

  static const String _baseUrl = "https://jsonplaceholder.typicode.com/";

  get statusCode => "";


    static Future<TodoUtils> addTodo(Todo todo) async{
    post(String apiUrl, {required Map<String, String> headers, required String body}) {
    }
    String apiUrl = "${_baseUrl}Todo";

    var response = post(apiUrl,
      headers: {
        'X-Parse-Application-Id' : kParseApplicationId,
        'X-Parse-REST-API-Key' : kParseRestApiKey,
        'Content-Type' : 'application/json'
      },
      body: json.encode(todo.toJson()),
    );

    return response;
  }


  static Future getTodoList() async{
    get(String apiUrl, {required Map<String, String> headers}) {
    }

    String apiUrl = "${_baseUrl}Todo";

    var response = get(apiUrl, headers: {
      'X-Parse-Application-Id' : kParseApplicationId,
      'X-Parse-REST-API-Key' : kParseRestApiKey,
    });

    return response;
  }


  static Future updateTodo(Todo todo) async{
    put(String apiUrl, {required Map<String, String> headers, required String body}) {
    }
    String apiUrl = "${_baseUrl}Todo/${todo.objectId}";

    var response = put(apiUrl, headers: {
      'X-Parse-Application-Id' : kParseApplicationId,
      'X-Parse-REST-API-Key' : kParseRestApiKey,
      'Content-Type' : 'application/json',
    },
        body: json.encode(todo.toJson())
    );

    return response;
  }


  static Future deleteTodo(String objectId) async{
    delete(String apiUrl, {required Map<String, String> headers}) {
    }
    String apiUrl = "${_baseUrl}Todo/$objectId";

    var response = delete(apiUrl, headers: {
      'X-Parse-Application-Id' : kParseApplicationId,
      'X-Parse-REST-API-Key' : kParseRestApiKey,
    });

    return response;
  }



}






