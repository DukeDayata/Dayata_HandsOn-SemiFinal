package com.example.todo_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
